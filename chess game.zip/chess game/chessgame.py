import pygame, sys, os, random, copy
from pygame.locals import *

pygame.init()

# --------- Constants ---------
WIDTH, HEIGHT = 700, 700  # Extra space for captured pieces
ROWS, COLS = 8, 8
SQUARE_SIZE = WIDTH // COLS

WHITE = (245, 245, 245)
BLACK = (70, 70, 70)
HIGHLIGHT = (200, 200, 0)
POSSIBLE = (100, 180, 255)
LAST_MOVE = (255, 200, 0)
FPS = 60
TIMER_FONT = pygame.font.SysFont('Arial', 24)

# --------- Load Images ---------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
IMAGE_DIR = os.path.join(BASE_DIR, 'images')
pieces_images = {}

for color in ['w', 'b']:
    for piece in ['K','Q','R','B','N','P']:
        path = os.path.join(IMAGE_DIR, f'{color}{piece}.png')
        image = pygame.image.load(path)
        pieces_images[f'{color}{piece}'] = pygame.transform.scale(image, (SQUARE_SIZE, SQUARE_SIZE))

# --------- Chess Board Setup ---------
def initial_board():
    return [
        ["bR","bN","bB","bQ","bK","bB","bN","bR"],
        ["bP"]*8,
        [""]*8,
        [""]*8,
        [""]*8,
        [""]*8,
        ["wP"]*8,
        ["wR","wN","wB","wQ","wK","wB","wN","wR"]
    ]

# --------- Utility ---------
def inside_board(r, c):
    return 0 <= r < 8 and 0 <= c < 8

def draw_board(screen, board, selected, possible_moves, last_move, captured):
    colors = [WHITE, BLACK]
    for r in range(ROWS):
        for c in range(COLS):
            rect = pygame.Rect(c*SQUARE_SIZE, r*SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE)
            pygame.draw.rect(screen, colors[(r+c)%2], rect)
            
            # Highlight last move
            if last_move and (r,c) in last_move:
                pygame.draw.rect(screen, LAST_MOVE, rect)
            
            # Highlight selected piece
            if selected == (r,c):
                pygame.draw.rect(screen,HIGHLIGHT, rect, 5)
            
            # Highlight possible moves
            if (r,c) in possible_moves:
                pygame.draw.circle(screen,POSSIBLE, (c*SQUARE_SIZE+SQUARE_SIZE//2, r*SQUARE_SIZE+SQUARE_SIZE//2), 10)
            
            piece = board[r][c]
            if piece:
                screen.blit(pieces_images[piece], rect.topleft)
    
    # Draw captured pieces
    margin = 5
    for i, piece in enumerate(captured['b']):
        screen.blit(pieces_images[piece], (i*(SQUARE_SIZE+margin), -SQUARE_SIZE))
    for i, piece in enumerate(captured['w']):
        screen.blit(pieces_images[piece], (i*(SQUARE_SIZE+margin), HEIGHT-SQUARE_SIZE))

# --------- Move Logic ---------
def get_possible_moves(board, row, col):
    moves = []
    piece = board[row][col]
    if not piece:
        return moves
    color, p_type = piece[0], piece[1]

    if p_type == "P":
        step = -1 if color=="w" else 1
        if inside_board(row+step, col) and board[row+step][col]=="":
            moves.append((row+step,col))
        if (color=="w" and row==6) or (color=="b" and row==1):
            if board[row+2*step][col]=="":
                moves.append((row+2*step,col))
        for dc in [-1,1]:
            r, c_ = row+step, col+dc
            if inside_board(r,c_) and board[r][c_] and board[r][c_][0]!=color:
                moves.append((r,c_))
    elif p_type=="N":
        for dr,dc in [(2,1),(1,2),(2,-1),(1,-2),(-2,1),(-1,2),(-2,-1),(-1,-2)]:
            r,c_ = row+dr,col+dc
            if inside_board(r,c_) and (not board[r][c_] or board[r][c_][0]!=color):
                moves.append((r,c_))
    elif p_type in ["R","B","Q"]:
        directions = []
        if p_type in ["R","Q"]: directions += [(1,0),(-1,0),(0,1),(0,-1)]
        if p_type in ["B","Q"]: directions += [(1,1),(1,-1),(-1,1),(-1,-1)]
        for dr,dc in directions:
            r,c_ = row+dr,col+dc
            while inside_board(r,c_):
                if board[r][c_]=="":
                    moves.append((r,c_))
                elif board[r][c_][0]!=color:
                    moves.append((r,c_))
                    break
                else:
                    break
                r+=dr
                c_+=dc
    elif p_type=="K":
        for dr,dc in [(1,0),(-1,0),(0,1),(0,-1),(1,1),(-1,-1),(1,-1),(-1,1)]:
            r,c_ = row+dr,col+dc
            if inside_board(r,c_) and (not board[r][c_] or board[r][c_][0]!=color):
                moves.append((r,c_))
    return moves

# --------- AI (Random) ---------
def random_ai(board, color):
    all_moves = []
    for r in range(8):
        for c in range(8):
            if board[r][c] and board[r][c][0]==color:
                for move in get_possible_moves(board,r,c):
                    all_moves.append(((r,c),move))
    return random.choice(all_moves) if all_moves else (None,None)

# --------- Main Game ---------
def main():
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Python Chess")
    clock = pygame.time.Clock()

    board = initial_board()
    selected = None
    possible_moves = []
    last_move = None
    turn = "w"
    ai_color = "b"
    captured = {'w':[], 'b':[]}

    # Timer
    total_time = 5*60*1000  # 5 minutes in ms
    timers = {"w": total_time, "b": total_time}
    last_tick = pygame.time.get_ticks()

    running = True
    while running:
        dt = pygame.time.get_ticks()-last_tick
        last_tick = pygame.time.get_ticks()
        timers[turn] -= dt

        for event in pygame.event.get():
            if event.type==QUIT:
                pygame.quit()
                sys.exit()
            elif event.type==MOUSEBUTTONDOWN:
                x,y = pygame.mouse.get_pos()
                row, col = y//SQUARE_SIZE, x//SQUARE_SIZE
                if turn!=ai_color:
                    if selected:
                        if (row,col) in possible_moves:
                            # Capture piece
                            if board[row][col]:
                                captured[board[row][col][0]].append(board[row][col])
                            board[row][col] = board[selected[0]][selected[1]]
                            board[selected[0]][selected[1]] = ""
                            last_move = [selected,(row,col)]
                            selected, possible_moves = None, []
                            turn = "b" if turn=="w" else "w"
                        else:
                            if board[row][col] and board[row][col][0]==turn:
                                selected = (row,col)
                                possible_moves = get_possible_moves(board,row,col)
                    else:
                        if board[row][col] and board[row][col][0]==turn:
                            selected = (row,col)
                            possible_moves = get_possible_moves(board,row,col)

        # AI move
        if turn==ai_color:
            pygame.time.delay(300)
            from_pos,to_pos = random_ai(board,ai_color)
            if from_pos and to_pos:
                if board[to_pos[0]][to_pos[1]]:
                    captured[board[to_pos[0]][to_pos[1]][0]].append(board[to_pos[0]][to_pos[1]])
                board[to_pos[0]][to_pos[1]] = board[from_pos[0]][from_pos[1]]
                board[from_pos[0]][from_pos[1]] = ""
                last_move = [from_pos,to_pos]
            turn = "w"

        # Draw everything
        draw_board(screen, board, selected, possible_moves, last_move, captured)

        # Draw timers
        w_time = TIMER_FONT.render(f"White: {timers['w']//1000}s", True, (0,0,0))
        b_time = TIMER_FONT.render(f"Black: {timers['b']//1000}s", True, (0,0,0))
        screen.blit(w_time,(10, HEIGHT-25))
        screen.blit(b_time,(WIDTH-b_time.get_width()-10, HEIGHT-25))

        pygame.display.flip()
        clock.tick(FPS)

if __name__=="__main__":
    main()
