# ♟️ Python Chess Game

A Pygame-based **Chess Game** featuring **Player vs AI** mode, move highlighting, captured piece display, and chess timers for both sides.  
It brings the traditional chess experience to life with an elegant board, smooth gameplay, and simple AI logic.

---

## 🎮 Features
- Supports all standard chess piece movements  
- Highlights selected pieces and possible moves  
- Displays last move and captured pieces  
- Includes a countdown timer for both players  
- AI plays random valid moves automatically  
- Clean, modern board UI using Pygame  

---

## 🧠 Tech Stack
- **Language:** Python 3  
- **Library:** Pygame  
- **IDE Recommended:** VS Code or PyCharm  

---

## ⚙️ How to Run
1. **Clone the repository**
   ```bash
   git clone https://github.com/<your-username>/python-chess-game.git
   cd python-chess-game
   ```

2. **Install dependencies**
   ```bash
   pip install pygame
   ```

3. **Add chess piece images**
   - Place all piece images (e.g. `wK.png`, `bQ.png`, etc.) inside an `images/` folder.  
   - Each image should be a square and clearly show the piece.

4. **Run the game**
   ```bash
   python chess.py
   ```

---

## 🚀 Future Enhancements
- Add check and checkmate logic  
- Implement smarter AI using Minimax algorithm  
- Include move history and undo functionality  
- Add multiplayer or online mode  

---

## 👩‍💻 Author
**Anamika**  
🎓 B.E. Computer Science & Design Engineer  
💡 Passionate about AI, coding, and game development.
